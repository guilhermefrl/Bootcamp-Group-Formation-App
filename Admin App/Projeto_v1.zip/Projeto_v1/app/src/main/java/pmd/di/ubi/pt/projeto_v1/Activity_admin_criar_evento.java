package pmd.di.ubi.pt.projeto_v1;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Activity_admin_criar_evento extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_criar_evento);
    }
    public void goToVerEquipas(){

    }
    public void goToVerEventos(){

    }
    public void goToCriarEvento(){

    }
}
